Contents of Class2.java
