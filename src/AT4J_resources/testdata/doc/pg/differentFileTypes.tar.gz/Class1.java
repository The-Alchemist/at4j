Contents of Class1.java
